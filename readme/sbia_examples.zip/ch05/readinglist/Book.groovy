class Book {
	Long id
	String reader
	String isbn
	String title
	String author
	String description
}